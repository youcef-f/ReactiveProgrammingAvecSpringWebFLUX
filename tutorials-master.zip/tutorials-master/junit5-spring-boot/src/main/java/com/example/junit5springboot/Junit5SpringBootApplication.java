package com.example.junit5springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Junit5SpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(Junit5SpringBootApplication.class, args);
	}
}

package com.spring.cloud.example.libraryservice;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class LibraryServiceApplicationTests {

	@Test
		public void contextLoads() {
	}

}
